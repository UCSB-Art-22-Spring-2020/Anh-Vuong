var total = 300;
var plist = [];

function setup() {
  createCanvas(400, 400);
   for ( let i=0; i < total; i++) {
    plist.push( new particles() );
   }
}

function draw() {
  background(0);
   for ( let i=0; i < plist.length; i++) {
    plist[i].display();
   }
}

class particles{
  contruct() {
    this.x = 200;
    this.y = 380;
    this.alpha = 255;
  }

  display() {
    //set caculations to make particles move
    this.x+= random (-1,1); 
    this.y+= random (-5,-1);
    
    this.alpha-=3;//set the alpha channel decrease along the particles movement --> create the fading effect
    
    strokeWeight(10);//set the thickness of particles to size
    stroke(255, random(0,200), random (0,50), this.alpha);//set colors of particles with alpha channel
    point(this.x, this.y);//draw particles as points
    
    // check for boundaries and redraw particles from their intitial position and intital alpha channel -->keep the fire up
    if( this.x > width || this.x < 0 || this.y > height || this.y < 0 ){
      this.x = 200;
      this.y = 380;
      this.alpha = 255;
    }
  }
}