var plist = []; // create array of the particles

function setup() {
  createCanvas(400, 400);

   for ( let i=0; i < 1000; i++) { //add the particles into the list or plist
    plist.push( new particles() );
   }
}

function draw() {
  background(250,128,114);
   for ( let i=0; i < plist.length; i++) { //loop through the particles
    plist[i].display();
   }
  noStroke();
  fill(0);
  ellipse (200, 380, 60, 10);
}

class particles{
  constructor() {
    this.x = 200; // initial x position
    this.y = 380; // initial y position
    this.alpha = 255; //initial alpha channel
  }

  display() {
    //set calculations to make particles move
    this.x += random (-5,5);
    this.y += random (-5,-1);
    this.alpha-=2
   
    strokeWeight(3);//set the thickness of particles to size
    let a = random (255);
    stroke(a, a, a, this.alpha); //set colors of particles with alpha channel
    point(this.x, this.y);//draw particles as points
   
    // check for boundaries and redraw particles from their initial position 
    if(this.x < 0 || this.x > width || this.y < 0 || this.y > height){
      this.x = 200;
      this.y = 380;
      this.alpha = 255;
    }
  }
}