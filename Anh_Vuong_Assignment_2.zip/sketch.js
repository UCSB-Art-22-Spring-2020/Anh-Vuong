function setup() {
  createCanvas(500, 400);
  x = width/2; //starting position in the middle
  // setting color of the snall rectangle (window) to white
  r = 255; 
  g = 255;
  b = 255;
}

function draw() {
  background(0);
  for (let i = 0; i < 100; i++) {//start counting at 0 and keep counting until it reaches 99
    let a = random(0, 500); //random "a" number from 0 to 499
    let b = random(0, 400); //random "b" number from 0 to 399 
    stroke(255);//color of lines (rain)
    line(a, b, a + 20, b + 20);//lines at random positions 
  }
  noStroke ();//no ouline 
  fill(27, 79, 114);//color of the rectangle (house)
  rect(x/2, 300, 250, 100);//position and dimension of the  rectangle (house)
  fill(202, 111, 30);//color of the triangle (roof)
  triangle(x/2, 300, x, 225, 3*x/2, 300);///position and dimension of the triangle (roof)
  fill(r, g, b);//color of the small rectangle (window)
  rect(x - 40, 325, 80, 50);//position and dimension of the small rectangle (window)
  }
    function keyPressed() {//keyboard interaction
      if (keyCode === RIGHT_ARROW) {//if keycode is the right arrow
        r = 255; g = 254; b = 243//color of the window  turns to yellowish
    } else if (keyCode === LEFT_ARROW) {//if keycode is the left arrow
        r = 254; g = 255; b = 0//color of the window turns bright yellow
    }
}