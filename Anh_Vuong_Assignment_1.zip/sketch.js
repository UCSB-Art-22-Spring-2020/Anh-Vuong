//Art 22 Spring 2020
//Author: Anh Vuong
//Assignment 1
//April 6, 2020

function setup() {
  createCanvas(400, 400); //the same as size in Processing
  //set x and y to middle of the screen
  x = width/2
  y = height/2
  //set the diameter of the circle
  a = 100
}

function draw() {
  fill(255,255,0);//colors of the circle in the top-left ang bottom-right quadrant
  circle(x/2, y/2, a);//position of the top-left circle
  circle(x + x/2, y + y/2, a);//position of the bottom-right circle
  fill (0);////colors of the circle in the top-right ang bottom-left quadrant
  circle(x + x/2, y/2, a);//position of the top-right circle
  circle(x/2, y + y/2, a);;//position of the bottom-left circle
  
  strokeWeight(30);//thickness of circle outline and point
  
point(mouseX, mouseY);// set location of the point to mouse
//if the mouse in the top-left and bottom-right quadrant or the top-right and bottom-left quadrant, the point and the strokes will change to yellow with some transparency (alpha channel). Else, they change to black with some transparency (alpha channel)
if (mouseX > 200 && mouseY > 200 || mouseX < 200 && mouseY < 200) {
  stroke(255, 255, 0, 50);
} else {
  stroke(0,0,0,50);
}

}